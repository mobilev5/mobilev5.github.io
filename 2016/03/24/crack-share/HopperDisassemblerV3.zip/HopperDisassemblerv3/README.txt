>>> 注意：

？插件作者：cigoL
？对于好的软件的开发者，请记得购买正版

http://www.hopperapp.com/
http://sites.fastspring.com/hopperapp/product/hopperdisassemblerv3

------------------------------------------------------------

目前在OSX 10.9上面会加载失败导致Hopper启动失败，解决方法待研究

用以下步骤破解Hopper：
1）把Hopper拖拽放入Applications（应用程序）文件夹
2）运行Applications（应用程序）文件夹中的Hopper
3）解压出cigoLivePatch.hopperTool插件，放到桌面，然后双击运行该插件，该插件会被Hopper安装到~/Library/Application Support/Hopper/PlugIns/Tools/文件夹下，
4）重启Hopper即可

为了避免授权被吊销，重要提示：
1）不要点击自动更新菜单，设置禁用自动更新
2）修改/etc/hosts, 添加以下一行内容
127.0.0.1  flashcode.cryptic-apps.com 

交流请到：
http://bbs.pediy.com
http://bbs.chinapyg.com/thread-79640-1-1.html
http://www.52pojie.cn
http://www.ccgcn.com

													--0xcb
-----------------------------------------------------------

https://kat.cr/user/cigoL